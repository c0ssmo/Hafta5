"""Decorator-based command registry for the space exploration exercise."""

KOMUTLAR = {}


def komut(ad, aciklama=""):
    """Register a command function under a unique name."""
    def dekorator(func):
        if ad in KOMUTLAR:
            raise ValueError(f"'{ad}' komutu zaten kayıtlı!")
        KOMUTLAR[ad] = (func, aciklama)
        return func
    return dekorator


@komut("yardim", "komutları listeler")
def komut_yardim(durum):
    return "\n".join(
        f"{ad}: {aciklama}" for ad, (_, aciklama) in KOMUTLAR.items()
    )


@komut("envanter", "envanter eşyalarını gösterir")
def komut_envanter(durum):
    return (
        f"Credits: {durum.get('credits', 0)}, "
        f"Engines: {durum.get('engines', [])}, "
        f"Copilot: {durum.get('copilot', 'Yok')}"
    )


@komut("harita", "gidebileceğin gezegenleri gösterir")
def komut_harita(durum):
    baglantilar = durum.get("baglantilar", [])
    return ", ".join(baglantilar)


def komut_calistir(ad, durum):
    """Run a registered command, raising KeyError for an unknown command."""
    try:
        func, _ = KOMUTLAR[ad]
    except KeyError:
        raise KeyError(f"Bilinmeyen komut: {ad}") from None
    return func(durum)
