import io
import unittest
from contextlib import redirect_stdout

from uzay_oyunu.dekoratorler import hafiza, log_cagri, say, sinirla, sure_olc
from uzay_oyunu.komutlar import KOMUTLAR, komut, komut_calistir


class DekoratorTestleri(unittest.TestCase):
    def test_sure_olc_korur_isim_ve_sonuc(self):
        @sure_olc
        def ornek_fonk(x):
            return x * 2

        output = io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(ornek_fonk(5), 10)
        self.assertEqual(ornek_fonk.__name__, "ornek_fonk")
        self.assertIn("ornek_fonk:", output.getvalue())

    def test_say_recursive_calls(self):
        @say
        def faktoriyel(n):
            return 1 if n <= 1 else n * faktoriyel(n - 1)

        self.assertEqual(faktoriyel(4), 24)
        self.assertEqual(faktoriyel.cagri, 4)

    def test_sinirla(self):
        @sinirla(0, 100)
        def yakit_harca(miktar):
            return 100 - miktar

        self.assertEqual(yakit_harca(30), 70)
        with self.assertRaises(ValueError):
            yakit_harca(150)

    def test_log_cagri(self):
        @log_cagri
        def topla(a, b=0):
            return a + b

        output = io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(topla(2, b=3), 5)
        self.assertIn("-> topla(2, b=3)", output.getvalue())
        self.assertIn("<- topla = 5", output.getvalue())

    def test_hafiza_ve_lru(self):
        calls = []

        @hafiza(maxsize=2)
        def hesapla(x):
            calls.append(x)
            return x * 2

        self.assertEqual(hesapla(1), 2)
        self.assertEqual(hesapla(1), 2)
        self.assertEqual(calls, [1])
        hesapla(2)
        hesapla(1)  # Mark key 1 as recently used.
        hesapla(3)  # Evicts key 2.
        hesapla(2)
        self.assertEqual(calls, [1, 2, 3, 2])
        hesapla.cache_clear()
        hesapla(1)
        self.assertEqual(calls[-1], 1)

    def test_hafiza_sifir_kapasite(self):
        calls = []

        @hafiza(maxsize=0)
        def hesapla(x):
            calls.append(x)
            return x

        hesapla(1)
        hesapla(1)
        self.assertEqual(calls, [1, 1])


class KomutTestleri(unittest.TestCase):
    def test_kayit_cakisma_ve_calistirma(self):
        ad = "test_komutu_unittest"

        @komut(ad, "test açıklaması")
        def ornek_komut(durum):
            return "başarılı"

        self.assertEqual(KOMUTLAR[ad][1], "test açıklaması")
        self.assertEqual(komut_calistir(ad, {}), "başarılı")
        with self.assertRaises(ValueError):
            komut(ad)(lambda durum: None)
        with self.assertRaises(KeyError):
            komut_calistir("olmayan", {})

    def test_harita_ve_envanter(self):
        self.assertEqual(komut_calistir("harita", {"baglantilar": ["Dünya", "Mars"]}), "Dünya, Mars")
        self.assertIn("Credits: 0", komut_calistir("envanter", {}))
        self.assertIn("yardim:", komut_calistir("yardim", {}))


if __name__ == "__main__":
    unittest.main()
