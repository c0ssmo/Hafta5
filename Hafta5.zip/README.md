# Hafta 5 — Dekoratörler ve Komutlar

**Öğrenci: Berke Baytöre  
**Öğrenci numarası: 20253005017

Bu çalışma, [nihateakdeniz-lgtm/hafta_5](https://github.com/nihateakdeniz-lgtm/hafta_5) deposundaki dekoratör ve komut kayıt örneklerini temel alır. Kaynak kodun kökeni açıkça belirtilmiştir. Aşağıda birleştirme sırasında yapılan düzenlemeler listelenmiştir.

## Proje yapısı

- `uzay_oyunu/dekoratorler.py`: süre ölçümü, çağrı sayımı, çağrı günlüğü, aralık doğrulama ve LRU önbellek dekoratörleri.
- `uzay_oyunu/komutlar.py`: benzersiz isimli komut kaydı, yardım/envanter/harita komutları ve komut çalıştırıcısı.
- `tests/test_hafta5.py`: standart kütüphane `unittest` ile kontroller.

## Düzenlemeler

- Modülleri `uzay_oyunu` paketi altında birleştirdim ve paket/test yapısını ekledim.
- Önbellekteki `maxisize`, `keys.order` ve tanımsız `maxsize` hatalarını düzelttim; LRU sıralamasını ve temizleme yöntemini ekledim.
- Komut modülüne kayıtlı komutu çalıştıran bir yardımcı ekledim.
- Kaynak testteki yanlış girintiyi düzelttim ve tüm kontrolleri `unittest` ile çalışacak biçimde düzenledim.

## Çalıştırma

Proje kök dizininden:

```bash
python -m unittest discover -s tests -v
```

Uygulama kodu Python standart kütüphanesini kullanır.
