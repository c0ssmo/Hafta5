"""Utility decorators used by the Hafta 5 exercise."""

from collections import OrderedDict
from functools import wraps
from time import perf_counter


def sure_olc(func):
    """Print elapsed runtime for each function call."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = perf_counter()
        try:
            return func(*args, **kwargs)
        finally:
            elapsed = perf_counter() - start
            print(f"{func.__name__}: {elapsed:.4f} sn")
    return wrapper


def say(func):
    """Count calls, including recursive calls, on the decorated function."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        wrapper.cagri += 1
        return func(*args, **kwargs)
    wrapper.cagri = 0
    return wrapper


def log_cagri(func):
    """Print call arguments and the returned value."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        args_str = ", ".join(repr(arg) for arg in args)
        kwargs_str = ", ".join(f"{key}={value!r}" for key, value in kwargs.items())
        all_args = ", ".join(part for part in (args_str, kwargs_str) if part)
        print(f"-> {func.__name__}({all_args})")
        result = func(*args, **kwargs)
        print(f"<- {func.__name__} = {result!r}")
        return result
    return wrapper


def sinirla(alt, ust):
    """Reject calls whose first positional argument is outside [alt, ust]."""
    def dekorator(func):
        @wraps(func)
        def wrapper(ilk_arg, *args, **kwargs):
            if not alt <= ilk_arg <= ust:
                raise ValueError(
                    f"{func.__name__}: {ilk_arg} değeri {alt}-{ust} aralığında değil"
                )
            return func(ilk_arg, *args, **kwargs)
        return wrapper
    return dekorator


def hafiza(maxsize=None):
    """Memoize calls, optionally evicting least recently used results."""
    if maxsize is not None and maxsize < 0:
        raise ValueError("maxsize negatif olamaz")

    def dekorator(func):
        cache = OrderedDict()

        @wraps(func)
        def wrapper(*args, **kwargs):
            key = (args, tuple(sorted(kwargs.items())))
            if key in cache:
                cache.move_to_end(key)
                return cache[key]
            result = func(*args, **kwargs)
            if maxsize != 0:
                cache[key] = result
                if maxsize is not None and len(cache) > maxsize:
                    cache.popitem(last=False)
            return result

        def cache_clear():
            cache.clear()

        wrapper.cache_clear = cache_clear
        return wrapper
    return dekorator
